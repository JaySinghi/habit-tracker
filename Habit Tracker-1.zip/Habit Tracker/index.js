import { registerRootComponent } from 'expo'
import Index from '~index'

registerRootComponent(Index)
