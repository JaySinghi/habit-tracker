export type WeeklyCalendarDateType = {
  day: string,
  date: string,
  isToday: boolean
}
