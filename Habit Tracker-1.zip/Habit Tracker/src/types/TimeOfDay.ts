export enum TimeOfDay {
  All = 'All',
  Morning = 'Morning',
  Afternoon = 'Afternoon',
  Evening = 'Evening'
}
