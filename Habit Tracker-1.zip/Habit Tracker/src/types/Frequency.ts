export enum Frequency {
  Daily = 'Daily',
  Weekly = 'Weekly',
}
