export type ProgressBarType = {
  progress: number,
}
