export enum HabitType {
  REGULAR,
  CHALLENGE
}
