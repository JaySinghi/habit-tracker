const DAY_NAME_OF_WEEK_LONG = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

export default DAY_NAME_OF_WEEK_LONG
