const DAY_NAME_OF_WEEK_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

export default DAY_NAME_OF_WEEK_SHORT
