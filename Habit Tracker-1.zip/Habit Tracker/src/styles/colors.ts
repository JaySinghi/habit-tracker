export const MAIN_BG_COLOR = '#FDFCF9'
export const SECONDARY_BG_COLOR = '#FFFFFF'
export const MAIN_ACCENT_COLOR = '#ED9107'
export const APP_GRAY = '#D9D9D9'
export const APP_LIGHT_GRAY = '#d0d0d0'
export const APP_GREEN = '#4BAE4F'
export const NAV_ICON_COLOR = '#9DB2CE'
export const APP_BLACK = '#000000'
export const APP_WHITE = '#FFFFFF'
export const APP_BLUE = '#082E67'
export const APP_GOLD = '#EFDA45'
export const HABIT_OPTION = '#565454'

export const APP_RED = '#F84A3E'

export const APP_PINK = '#F5B6B1'

export const GRAY_TEXT = '#333333'


